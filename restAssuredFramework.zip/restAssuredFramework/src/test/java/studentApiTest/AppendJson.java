package studentApiTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.testng.annotations.Test;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
 
public class AppendJson {
 
	@Test
	public void quickEditToJsonObject() throws IOException {
		FileInputStream fileInputStream = new FileInputStream(new File(".\\Payloads\\payload.json"));
 
		// Creating an instance of ObjectMapper class
		ObjectMapper objectMapper = new ObjectMapper();
		// Get ObjectNode representation of json as json is an Object
		ObjectNode objectNode = objectMapper.readValue(fileInputStream, ObjectNode.class);
		
		objectNode.put("fileContent", "Updated Test");
		//objectNode.with("bookingDetails").put("firstname", "Rahul");
		System.out.println(objectNode.toString());
	}
 
}