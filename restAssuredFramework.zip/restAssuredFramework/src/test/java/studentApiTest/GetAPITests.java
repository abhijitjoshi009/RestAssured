package studentApiTest;

import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import apiConfigs.APIPath;
import apiConfigs.HeaderConfigs;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import utils.GlobalVariable;

public class GetAPITests extends BaseTest {

	@Test
	public void getAPITest() {

		test.log(LogStatus.INFO, "My test is starting for GET all Endpoint......");
		HeaderConfigs header = new HeaderConfigs();
		Response response = RestAssured.given().headers(header.defaultHeaders()).relaxedHTTPSValidation().when()
				.get(APIPath.apiPath.GET_LIST_OF_POSTS);

		APIVerification.responseCodeValiddation(response, 200);
		APIVerification.responseTimeValidation(response);
		test.log(LogStatus.INFO, "My test is ended......");

	}

	@Test
	public void getAPITestSpecific() {

		test.log(LogStatus.INFO, "My test is starting for specific GET endpoint ......");
		HeaderConfigs header = new HeaderConfigs();
		Response response = RestAssured.given().relaxedHTTPSValidation().headers(header.defaultHeaders())
				.queryParam("id", GlobalVariable.post_id).when().get(APIPath.apiPath.GET_LIST_OF_POSTS);

		APIVerification.responseCodeValiddation(response, 200);
		APIVerification.responseTimeValidation(response);
		test.log(LogStatus.INFO, "My test is ended......");

	}

}