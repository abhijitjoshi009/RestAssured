package studentApiTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.relevantcodes.extentreports.LogStatus;
import baseTest.BaseTest;


public class SQLConnector extends BaseTest {

    // Declaration of the variables
    
    private final String url = "jdbc:postgresql://localhost/dvdrental"; //connection string
    private final String user = "postgres";
    private final String password = "postgres";
    public static String fname = null;

    // Method to initiate connection to the database and execute query
    
    public String connect()  {
    	
    	test.log(LogStatus.INFO, "Data Base Connection is in progress....");
    	
    	String a = null;
        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            {
                if (conn != null) {

                    PreparedStatement pst = conn.prepareStatement("select first_name from actor where last_name = 'Lollobrigida'");
                    ResultSet rs = pst.executeQuery();
                    {
                        while (rs.next()) {

                            fname = rs.getString("first_name");
                            a = a +" " +fname;
                            //System.out.println("The value from the table is : "+fname);
                        }
                    }

                } else
                    System.out.println("Failed to connect");
                test.log(LogStatus.FAIL, "Data Base Connection is failed....");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return a;
    }
    

    // Main method and Rest Assured Code v
    
 //   public static void main(String[] args)  {
  //      SQLConnector app = new SQLConnector();
   //     app.connect();      
  //      RestAssured.given().when().get(APIPath.apiPath.GET_LIST_OF_POSTS);
   //     System.out.println("Execution Successful");
   // }

}