package studentApiTest;

import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import apiConfigs.APIPath;
import apiConfigs.HeaderConfigs;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;


public class DeleteAPITest extends BaseTest {

	@Test
	public void deleteAPITest() {

		test.log(LogStatus.INFO, "My test is starting for DELETE endpoint ......");
		HeaderConfigs header = new HeaderConfigs();
		// Response response =
		// RestAssured.given().relaxedHTTPSValidation().when().log().all().get(APIPath.apiPath.GET_LIST_OF_POSTS);

		Response response = RestAssured.given().relaxedHTTPSValidation().headers(header.defaultHeaders())
				.delete(APIPath.apiPath.DELETE);

		APIVerification.responseCodeValiddation(response, 204);
		APIVerification.responseTimeValidation(response);

		test.log(LogStatus.INFO, "My test is ended......");

	}

}