package studentApiTest;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import apiConfigs.APIPath;
import apiConfigs.HeaderConfigs;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import utils.FileandEnv;
import utils.GlobalVariable;

public class PostAPITest extends BaseTest {

	private String _baseUrl = "";

	PostAPITest() {
		_baseUrl = FileandEnv.envAndFile().get("ServerUrl");
	}

	String id;

	@Test(priority = 1)
	public void validPostAPITest() throws IOException {

		test.log(LogStatus.INFO, "My test is starting.....");
		HeaderConfigs header = new HeaderConfigs();
		FileInputStream fileInputStream = new FileInputStream(new File(".\\Payloads\\register.json"));
		String url = _baseUrl + APIPath.apiPath.CREATE_POST;
		Response response = RestAssured.given().relaxedHTTPSValidation().when()
				.headers(header.defaultHeaders()).body(IOUtils.toString(fileInputStream, "UTF-8")).when().post(url);

		// Fetching ID from POST method for specific GET method
		JsonPath js = response.jsonPath();
		String id = js.getString("id");
		GlobalVariable.post_id = id;

		APIVerification.responseKeyValidationFromJsonObject(response, "id");
		APIVerification.responseCodeValiddation(response, 201);
		APIVerification.responseTimeValidation(response);

		test.log(LogStatus.INFO, "My test has been ended.....");

	}

	// @Test(priority =2)
	// public void invalidPostAPITest() {

	// }

}