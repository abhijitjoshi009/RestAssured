package studentApiTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
import apiConfigs.APIPath;
import apiConfigs.HeaderConfigs;
import apiVerifications.APIVerification;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import utils.FileandEnv;

public class PutAPITest extends BaseTest {

	private String _baseUrl = "";

	PutAPITest() {
		_baseUrl = FileandEnv.envAndFile().get("ServerUrl");
	}

	String id;

	@Test
	public void validPutAPITest() throws IOException {

		test.log(LogStatus.INFO, "My test is starting for PUT Method.....");
		HeaderConfigs header = new HeaderConfigs();
		FileInputStream fileInputStream = new FileInputStream(new File(".\\Payloads\\put.json"));

		String url = _baseUrl + APIPath.apiPath.CREATE_POST;
		Response response = RestAssured.given().relaxedHTTPSValidation().when().headers(header.defaultHeaders())
				.body(IOUtils.toString(fileInputStream, "UTF-8")).when().put(url);

		APIVerification.responseKeyValidationFromJsonObject(response, "id");
		APIVerification.responseCodeValiddation(response, 200);
		APIVerification.responseTimeValidation(response);

		test.log(LogStatus.INFO, "My test has been ended.....");

	}

}