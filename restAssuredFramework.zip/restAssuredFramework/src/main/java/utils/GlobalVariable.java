package utils;

public class GlobalVariable {

	public static String post_id = "1014";

}
