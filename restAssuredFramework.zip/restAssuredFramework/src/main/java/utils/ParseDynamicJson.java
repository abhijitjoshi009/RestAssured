package utils;

import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class ParseDynamicJson {

	// How to parse dynamic JSON?
	// How to parse nested JSON?

	public static void parseObject(JSONObject json, String key) {
		// System.out.println(json.has(key));
		System.out.println(json.get(key));
	}

	public static void getKey(JSONObject json, String key) {

		boolean exists = json.has(key);
		Iterator<?> keys;
		String nextKeys;

		if (!exists) {
			keys = json.keys();
			while (keys.hasNext()) {
				nextKeys = (String) keys.next();
				try {

					if (json.get(nextKeys) instanceof JSONObject) {

						if (exists == false) {
							getKey(json.getJSONObject(nextKeys), key);
						}

					} else if (json.get(nextKeys) instanceof JSONArray) {
						JSONArray jsonarray = json.getJSONArray(nextKeys);
						for (int i = 0; i < jsonarray.length(); i++) {
							String jsonarrayString = jsonarray.get(i).toString();
							JSONObject innerJSOn = new JSONObject(jsonarrayString);

							if (exists == false) {
								getKey(innerJSOn, key);
							}

						}

					}

				} catch (Exception e) {
					// TODO: handle exception
				}

			}

		} else {
			parseObject(json, key);
		}

	}

	public static void main(String[] args) {

		String inputJson = "{\"widget\": {\r\n"
				+ "    \"debug\": \"on\",\r\n"
				+ "    \"window\": {\r\n"
				+ "        \"title\": \"Sample Konfabulator Widget\",\r\n"
				+ "        \"name\": \"main_window\",\r\n"
				+ "        \"width\": 500,\r\n"
				+ "        \"height\": 500\r\n"
				+ "    },\r\n"
				+ "    \"image\": { \r\n"
				+ "        \"src\": \"Images/Sun.png\",\r\n"
				+ "        \"name\": \"sun1\",\r\n"
				+ "        \"hOffset\": 250,\r\n"
				+ "        \"vOffset\": 250,\r\n"
				+ "        \"alignment\": \"center\"\r\n"
				+ "    },\r\n"
				+ "    \"text\": {\r\n"
				+ "        \"data\": \"Click Here\",\r\n"
				+ "        \"size\": 36,\r\n"
				+ "        \"style\": \"bold\",\r\n"
				+ "        \"name\": \"text1\",\r\n"
				+ "        \"hOffset\": 250,\r\n"
				+ "        \"vOffset\": 100,\r\n"
				+ "        \"alignment\": \"center\",\r\n"
				+ "        \"onMouseUp\": \"sun1.opacity = (sun1.opacity / 100) * 90;\"\r\n"
				+ "    }\r\n"
				+ "}} ";
		JSONObject inputJSONOBject = new JSONObject(inputJson);

		getKey(inputJSONOBject, "name");

	}

}
