package utils;

import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import io.restassured.RestAssured;

public class payload {

	public static String jsonBody;
	
	public String generateStringFromResource(String path) throws IOException {

		return new String(Files.readAllBytes(Paths.get(path)));
		
		

	}

	
	public payload(String path) throws IOException {

		jsonBody = generateStringFromResource(path);

	//RestAssured.baseURI = "http://localhost:3000/posts";
		//RestAssured.given().header("Content-type", "application/json").body(jsonBody).when().post().then().log().all().assertThat().statusCode(201);

	}

}
