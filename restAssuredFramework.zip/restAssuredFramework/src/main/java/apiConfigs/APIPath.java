package apiConfigs;

import utils.GlobalVariable;

public class APIPath {
	
	public static final class apiPath{
		
		//GET
		public static final String GET_LIST_OF_POSTS ="firmware-files";
		public static final String GET_SINGLE_POST="posts/";
		
		//POST
		public static final String CREATE_POST="/register";
		
		
		//Put
		public static final String PUT="firmware-files";
		
		
		//Delete
		public static final String DELETE="firmware-files/" + GlobalVariable.post_id;
	}
	
}
