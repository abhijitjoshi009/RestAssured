package apiConfigs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class HeaderConfigs {
	
	public HeaderConfigs() {
		
	}
	
	public Map<String, String> defaultHeaders(){
		Map<String, String> defalutHeaders = new HashMap<String, String>();
		defalutHeaders.put("Authorization",  "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJQd2tyT3lqbHowZHRMNnhDeTMteXF1YndLM0VfQl9CN2Jxay1BaVBSTzE4In0.eyJqdGkiOiJhOGE1ZGEzYi1kNjBhLTQ2MDgtYWIwNy1mN2E5MTEzMGYwYjYiLCJleHAiOjE2NjAwNTg2OTEsIm5iZiI6MCwiaWF0IjoxNjYwMDQwNjkxLCJpc3MiOiJodHRwOi8vNTIuMTcyLjIyOS40Mzo4MDkwL2F1dGgvcmVhbG1zL2poaXBzdGVyIiwiYXVkIjpbInJlYWxtLW1hbmFnZW1lbnQiLCJhY2NvdW50Il0sInN1YiI6IjRjOTczODk2LTU3NjEtNDFmYy04MjE3LTA3YzVkMTNhMDA0YiIsInR5cCI6IkJlYXJlciIsImF6cCI6IndlYl9hcHAiLCJhdXRoX3RpbWUiOjAsInNlc3Npb25fc3RhdGUiOiI1YTE2ODJiMi1jMzdjLTRiYTMtOGE0MS03N2UzNWYyMDU2MzYiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIlJPTEVfT1RBX0FETUlOIiwiUk9MRV9VU0VSIiwib2ZmbGluZV9hY2Nlc3MiLCJST0xFX0FETUlOIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJyZWFsbS1tYW5hZ2VtZW50Ijp7InJvbGVzIjpbInZpZXctcmVhbG0iLCJ2aWV3LWlkZW50aXR5LXByb3ZpZGVycyIsIm1hbmFnZS1pZGVudGl0eS1wcm92aWRlcnMiLCJpbXBlcnNvbmF0aW9uIiwicmVhbG0tYWRtaW4iLCJjcmVhdGUtY2xpZW50IiwibWFuYWdlLXVzZXJzIiwicXVlcnktcmVhbG1zIiwidmlldy1hdXRob3JpemF0aW9uIiwicXVlcnktY2xpZW50cyIsInF1ZXJ5LXVzZXJzIiwibWFuYWdlLWV2ZW50cyIsIm1hbmFnZS1yZWFsbSIsInZpZXctZXZlbnRzIiwidmlldy11c2VycyIsInZpZXctY2xpZW50cyIsIm1hbmFnZS1hdXRob3JpemF0aW9uIiwibWFuYWdlLWNsaWVudHMiLCJxdWVyeS1ncm91cHMiXX0sImFjY291bnQiOnsicm9sZXMiOlsibWFuYWdlLWFjY291bnQiLCJtYW5hZ2UtYWNjb3VudC1saW5rcyIsInZpZXctcHJvZmlsZSJdfX0sInNjb3BlIjoiamhpcHN0ZXIgZHRjOndyaXRlIGRldmljZTp3cml0ZSB2ZWhpY2xlOnJlYWQgZW1haWwgZGV2aWNlOnJlYWQgcHJvZmlsZSBkdGM6cmVhZCB2ZWhpY2xlOndyaXRlIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsInJvbGVzIjpbIlJPTEVfT1RBX0FETUlOIiwiUk9MRV9VU0VSIiwib2ZmbGluZV9hY2Nlc3MiLCJST0xFX0FETUlOIiwidW1hX2F1dGhvcml6YXRpb24iXSwibmFtZSI6IlNlcmdpbyBNYXNzaW1vIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiYWRtaW4iLCJsb2NhbGUiOiJpbi1lbiIsImdpdmVuX25hbWUiOiJTZXJnaW8iLCJmYW1pbHlfbmFtZSI6Ik1hc3NpbW8iLCJlbWFpbCI6Imtvd3NoaWsuc0BrcGl0LmNvbSJ9.oaTaoUcO8NuQKHMzgu7pIgTsmOntF9jZGhTtQMMw1aEI_7ZNRWMeyVKGey6Jps-Q4UK2p9u0H5S6fq0lHHx6e16kOfNzHTa0vuBKMLfpq8AbyIQi71xj6j9NhNFXxyeoUQpMJCNQ-QL3rGd8nPfy-5WV2esIOqj8Z0tC3qxH4dkCWCF0cwIUQg-txaQVL7GiBFjGjMIeeddSJlfvK8zZk_HUteuEGSirnzIPfSvdlDBBFiGoV0f-edeIvMA2QOFOEDbopi1GxXFUVdY4zjtQVQZ_y436uPzmAdd9IAiUgRPmNGiC06PiAeFa5vZ2Xxy_5vsCjWlUXojIUOQ8BCpncQ");
		defalutHeaders.put("Content-Type", "application/json");
		
		
		
		return defalutHeaders;	
		
	}
	
	
	public Map<String, String> headersWithToken(){
		Map<String, String> defalutHeaders = new HashMap<String, String>();
		defalutHeaders.put("Content-Type", "application/json");
		defalutHeaders.put("Acess_Token", "sdjhvbshjdvbjhsdvbhjsdvbljhdsbv");
		defalutHeaders.put("jwt_token", "sdjhvbshjdvbjhsdvbhjsdvbljhdsbv");
		defalutHeaders.put("Tenet_user", "test");
	
		
		return defalutHeaders;
		
	}
	
//	public Map<String, String> headersWithToken(){
//		Map<String, String> defalutHeaders = new HashMap<String, String>();
//		defalutHeaders.put("Content-Type", "application/json");
//		defalutHeaders.put("Acess_Token", "sdjhvbshjdvbjhsdvbhjsdvbljhdsbv");
//		defalutHeaders.put("jwt_token", "sdjhvbshjdvbjhsdvbhjsdvbljhdsbv");
//		defalutHeaders.put("Tenet_user", "test");
//		
//		return defalutHeaders;
//		
//	}
	
	

}
