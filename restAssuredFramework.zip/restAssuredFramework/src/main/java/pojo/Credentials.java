package pojo;

public class Credentials {
	
	private String Credentials;

	public String getCredentials() {
		return Credentials;
	}

	public void setCredentials(String credentials) {
		this.Credentials = credentials;
	}
	

}