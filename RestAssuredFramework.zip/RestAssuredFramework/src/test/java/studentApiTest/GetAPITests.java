package studentApiTest;

import org.testng.annotations.Test;

import org.json.JSONArray;
import org.json.JSONObject;

import apiConfigs.APIPath;
import baseTest.BaseTest;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAPITests extends BaseTest {

	@Test
	public void getAPITest() {

		//RestAssured.given().when().get(APIPath.apiPath.GET_LIST_OF_POSTS).then().log().all().statusCode(200);

		Response response = RestAssured.given().when().get(APIPath.apiPath.GET_LIST_OF_POSTS);
		
	//	System.out.println(response.getBody().asString());
		
	//	System.out.println(response.statusCode());
		
	//	System.out.println(response.getCookies());
		
//		System.out.println(response.getTime());
		
		
		JSONArray array = new JSONArray(response.getBody().asString());
		
		for(int i=0; i<array.length(); i++) {
			//System.out.println(array.getInt(i));
			
			JSONObject obj = array.getJSONObject(i);
			System.out.println(obj.get("title"));
			
		}
	}

}
