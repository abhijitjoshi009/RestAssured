package utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.io.FileInputStream;

public class FileandEnv {

	public static Map<String, String> fileandenv = new HashMap<String, String>();
	public static Properties propMain = new Properties();
	public static Properties propPreSet = new Properties();

	public static Map<String, String> envAndFile() {

		String enviroment = System.getProperty("env");

		try {

			if (enviroment.equalsIgnoreCase("dev")) {

				FileInputStream fisDev = new FileInputStream(System.getProperty("user.dir") + "inputs/dev.properties");
				propMain.load(fisDev);
				fileandenv.put("ServerUrl", propMain.getProperty("ServerUrl"));
				fileandenv.put("PortN0", propMain.getProperty("PortN0"));
				fileandenv.put("Username", propMain.getProperty("Username"));
				fileandenv.put("Password", propMain.getProperty("Password"));

			} else if (enviroment.equalsIgnoreCase("qa")) {

				FileInputStream fisQA = new FileInputStream(System.getProperty("user.dir") + "inputs/qa.properties");
				propMain.load(fisQA);
				fileandenv.put("ServerUrl", propMain.getProperty("ServerUrl"));
				fileandenv.put("PortN0", propMain.getProperty("PortN0"));
				fileandenv.put("Username", propMain.getProperty("Username"));
				fileandenv.put("Password", propMain.getProperty("Password"));

			} else if (enviroment.equalsIgnoreCase("stagging")) {

				FileInputStream fisstagging = new FileInputStream(
						System.getProperty("user.dir") + "inputs/stagging.properties");
				propMain.load(fisstagging);
				fileandenv.put("ServerUrl", propMain.getProperty("ServerUrl"));
				fileandenv.put("PortN0", propMain.getProperty("PortN0"));
				fileandenv.put("Username", propMain.getProperty("Username"));
				fileandenv.put("Password", propMain.getProperty("Password"));

			}
		} catch (Exception e) {

		}

		return fileandenv;

	}

	public static Map<String, String> getConfigReader() {

		if (fileandenv == null) {
			fileandenv = envAndFile();
		}
		return fileandenv;

	}

}
